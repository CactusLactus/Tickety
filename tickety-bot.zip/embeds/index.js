module.exports = {
  DefaultEmbed: require("./DefaultEmbed"),
  ErrorEmbed: require("./ErrorEmbed"),
  SuccessEmbed: require("./SuccessEmbed"),
};
